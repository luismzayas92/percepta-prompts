Red Carpet Portrait System™
===========================

Gracias por adquirir este System de PERCEPTA LAB.

QUÉ ES ESTE SYSTEM
-------------------
Retrato editorial de alfombra roja de premiación: sonrisa natural, backdrop de step-and-repeat y estilismo de gala en negro con detalles dorados.

Categoría: Retrato editorial
Nivel: Principiante
Tiempo estimado de uso: 2–3 minutos
Compatible con: ChatGPT, Gemini, Claude, Grok

CONTENIDO DE ESTA CARPETA
--------------------------
- prompt.txt            El prompt maestro, listo para copiar y pegar.
- negative-prompt.txt   Restricciones para evitar resultados no deseados.
- How-to.txt            Guía paso a paso para obtener el mejor resultado.
- Ejemplos/preview.jpg  Ejemplo de referencia del resultado esperado.
- preview.jpg           Imagen de portada del System.
- Bonus.txt             Contenido adicional exclusivo de este System.

SOPORTE
-------
¿Dudas o feedback? Escríbenos — PERCEPTA LAB sigue mejorando cada System
con base en cómo lo usan sus clientes.

© PERCEPTA. Diseñamos percepción.
